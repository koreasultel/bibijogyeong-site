# 비비조경 홈페이지 미리보기

비비조경 예초·벌초 홈페이지 시안입니다.

## 바로 열어보기

이 폴더를 받은 뒤 `index.html` 파일을 더블클릭하면 브라우저에서 바로 열립니다.

필요한 파일은 아래 2개입니다.

- `index.html`
- `assets/bibi-brand-mark.jpg`

## GitHub Pages로 공유하기

친구나 지인에게 링크로 보여주려면 GitHub Pages를 사용하면 됩니다.

### 1. GitHub 저장소 만들기

1. GitHub에 로그인합니다.
2. 오른쪽 위 `+` 버튼을 누릅니다.
3. `New repository`를 선택합니다.
4. 저장소 이름을 입력합니다.
   - 예: `bibi-landscape`
5. 공개 설정은 `Public`으로 둡니다.
6. `Create repository`를 누릅니다.

### 2. 파일 올리기

저장소 화면에서 `uploading an existing file`을 누른 뒤 아래 파일과 폴더를 올립니다.

- `index.html`
- `assets` 폴더
- `.nojekyll`

업로드 후 `Commit changes`를 누릅니다.

### 3. GitHub Pages 켜기

1. 저장소 상단의 `Settings`로 이동합니다.
2. 왼쪽 메뉴에서 `Pages`를 누릅니다.
3. `Build and deployment`에서 다음처럼 선택합니다.
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
4. `Save`를 누릅니다.

몇 분 뒤 아래 형식의 주소가 생깁니다.

```txt
https://깃허브아이디.github.io/bibi-landscape/
```

이 주소를 친구들에게 보내면 홈페이지 시안을 볼 수 있습니다.

## 나중에 바꿀 것

- 실제 전화번호
- 실제 카카오톡 상담 링크
- 고화질 비비조경 로고
- 직접 촬영한 예초·벌초 영상
- 실제 서비스 가능 지역
